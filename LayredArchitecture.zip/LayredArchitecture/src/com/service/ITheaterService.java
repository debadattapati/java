package com.service;

import java.util.HashMap;
import java.util.List;

import com.model.Theater;

public interface ITheaterService {
	public abstract int addTheater(Theater theater);
	public abstract int deleteTheater(int tid);
	public abstract int updateTheater(int tid);
	public abstract Theater getByName(String name);
	public abstract Theater getByName(int id);
	public abstract HashMap<Integer,Theater> getAll();
}
