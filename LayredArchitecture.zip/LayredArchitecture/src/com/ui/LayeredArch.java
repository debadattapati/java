package com.ui;



import java.time.LocalDateTime;
import java.util.Scanner;

import com.model.Theater;
import com.service.ITheaterService;
import com.service.TheaterServiceImpl;

public class LayeredArch {

	public static void main(String[] args) {
		//UI
		System.out.println("****Theater Management System****");
		//printf(%3s
		while(true) {
		
		System.out.println(" 1. Add Theater \n 2. delete Theater\n 3. update Theater"
				+ "\n 4. get Theater by name \n 5. getTheater by id \n 6. get all theater list\n 7. exit");
		Scanner scan=new Scanner(System.in);
		System.err.println("Enter ur choice!!!");
		int option =scan.nextInt();
		ITheaterService iserv=new TheaterServiceImpl();
		
		switch(option) {
		case 1:
			System.out.println("enter name of the theater");
			String name=scan.next();
			System.out.println("enter no of screens");
			int screens=scan.nextInt();
			System.out.println("enter ,location");
			String loc=scan.next();
			System.out.println("enter show date&time(YYYY-MONTH-DATE_T_HOUR:MINUIT:SECOND)");
			String tdate=scan.next();
			
			
			LocalDateTime ldt=LocalDateTime.parse(tdate);
			
			Theater theater=new Theater(name,loc,screens,ldt);
		
			iserv.addTheater(theater);
				break;
		case 2:
		case 3: 
			
		case 6:
				iserv.getAll();
			
			break;
			
			default:
				System.exit(10);
		}	
	}
	}
}
